#ifndef MYCOUNTER_H
#define MYCOUNTER_H
int next_counter(int current);
#endif
